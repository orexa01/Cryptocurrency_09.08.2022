package com.cryptocurrency_java.cryptocurrency_java;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class VolatilityChart extends Fragment implements View.OnClickListener, Postman{


    TextView view;
    Button buttonExit;
    Activity activity;
    public VolatilityChart() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.volatility_chart, container, false);
        // Inflate the layout for this fragment
        buttonExit = view.findViewById(R.id.buttonExit);
        buttonExit.setOnClickListener(this);

        return view;
    }

    public void setSelectedItem(String data) {
        view = getView().findViewById(R.id.detailsText);
        view.setText(data);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
            activity =(Activity) context;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.buttonExit:
                ((Postman)activity).VolatilityChartButtonClick(true);
                break;
        }
    }

    @Override
    public void VolatilityChartButtonClick(boolean flag) {

    }
}
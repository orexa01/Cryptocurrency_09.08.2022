package com.cryptocurrency_java.cryptocurrency_java;

public interface Postman {

    public void VolatilityChartButtonClick(boolean flag);


}

package com.cryptocurrency_java.cryptocurrency_java;

import android.content.Context;
import android.content.pm.Attribution;
import android.util.AttributeSet;
import android.view.View;

public class ChartView extends View {



    public ChartView(Context context) {
        super(context);
    }

    public ChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}

package com.cryptocurrency_java.cryptocurrency_java;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements crypto_view.OnFragmentSendDataListener, Postman, View.OnClickListener, ToolBar.ToolBarButtonClick{

    crypto_view[] crypto_views = new crypto_view[40];
    LinearLayout mainLinerLayout;
    androidx.fragment.app.FragmentContainerView fragmentContainerView;
    public int screenID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainLinerLayout = findViewById(R.id.hi);
        fragmentContainerView = findViewById(R.id.volatility_chart);
        for (int i = 0; i < crypto_views.length; i++){
            crypto_views[i] = new crypto_view(i);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.hi, crypto_views[i], null)
                    .commit();
        }
    }

    @Override
    public void onSendText(String text) {
        VolatilityChart volatilityChart = (VolatilityChart) getSupportFragmentManager().findFragmentById(R.id.volatility_chart);
        if (volatilityChart != null) {
            GoneView(fragmentContainerView);
            volatilityChart.setSelectedItem(text);
        }
    }

    @Override
    public void VolatilityChartButtonClick(boolean flag) {
        if(flag){
            GoneView(mainLinerLayout);
        }
        else {
            GoneView(mainLinerLayout);
        }
    }

    @Override
    public void ToolBarClick(int idButtonClick) {
        switch (idButtonClick){
            case 0: GoneView(mainLinerLayout); break; // next
            case 1: alertDialog(); break; // menu
        }
    }

    public void GoneView(View view){
        fragmentContainerView.setVisibility(View.GONE);
        mainLinerLayout.setVisibility(View.GONE);
        view.setVisibility(View.VISIBLE);
        if(view == mainLinerLayout) screenID = 0;
        else screenID = 1;
    }

    public void alertDialog(){
        final String[] mCatsName ={"Тимка", "Пушок", "Кузя"};
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setIcon(R.drawable.bitcoin)
                .setTitle("Menu")
//                .setMessage("Exiting will call finish() method")
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        Toast.makeText(getApplicationContext(),"No",Toast.LENGTH_LONG).show();
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        Toast.makeText(getApplicationContext(),"Yes",Toast.LENGTH_LONG).show();
                    }
                })
                .setSingleChoiceItems(mCatsName, -1,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int item) {
                                Toast.makeText(getApplicationContext(), "Любимое имя кота: " + mCatsName[item], Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                .show();
//        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//        builder.setTitle("Важное сообщение!")
//                .setMessage("Закройте окно!")
//                .setIcon(R.drawable.bitcoin)
//                .setCancelable(false)
//                .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        Toast.makeText(getApplicationContext(),"No",Toast.LENGTH_LONG).show();
//                    }
//                })
//                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        Toast.makeText(getApplicationContext(),"Yes",Toast.LENGTH_LONG).show();
//                    }
//                });
//        AlertDialog alert = builder.create();
//        alert.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if(keyCode == KeyEvent.KEYCODE_BACK)
        {
            if(screenID == 0 || screenID == -1){
                if(screenID == -1) finish();
                else {
                    Toast.makeText(this, "Нажмите еще раз!", Toast.LENGTH_SHORT).show();
                    screenID = -1;
                }
            }
            else GoneView(mainLinerLayout);
        }
        return true;
    }

}